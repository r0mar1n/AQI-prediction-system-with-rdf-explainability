import os
import joblib
import pandas as pd
from rdflib import Graph, Namespace, URIRef, Literal, RDF, XSD

# --- CONFIGURATION & PATHS ---
# Since the script is in the same folder as the data, we use the current directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Point directly to the files in the same folder
MODEL_PATH = os.path.join(BASE_DIR, "final_aqi_prediction.pkl")
CSV_PATH = os.path.join(BASE_DIR, "Combined_AQ_Weather_NO2_AQI_2024_Robust.csv")

# Define Namespaces
AQ = Namespace("http://aqi-prediction.org/ontology#")
XSD_NS = Namespace("http://www.w3.org/2001/XMLSchema#")

# --- 1. INITIALIZE THE GRAPH ---
def init_graph():
    g = Graph()
    g.bind("aq", AQ)  # clearer prefix for your output
    return g

# --- 2. ADD EXPERT KNOWLEDGE (The "Explainability" Layer) ---
def add_expert_knowledge(g):
    """
    Adds static domain knowledge about pollutants.
    This links raw data (PM2.5) to human-understandable concepts (Traffic).
    """
    knowledge_base = {
        "PM2.5": {"source": "Vehicle exhaust, construction dust", "risk": "Respiratory issues"},
        "PM10":  {"source": "Dust storms, agriculture", "risk": "Lung irritation"},
        "NO2":   {"source": "Burning of fossil fuels (cars)", "risk": "Asthma aggravation"},
        "Ozone": {"source": "Chemical reaction in sunlight", "risk": "Chest pain, coughing"},
        "CO":    {"source": "Incomplete combustion", "risk": "Reduces oxygen delivery"},
        "temperature": {"source": "Meteorological condition", "risk": "Heat creates ozone"},
    }

    for feature, info in knowledge_base.items():
        feat_uri = URIRef(f"http://aqi-prediction.org/ontology#Feature_{feature}")
        g.add((feat_uri, RDF.type, AQ.EnvironmentalFeature))
        g.add((feat_uri, AQ.hasLikelySource, Literal(info['source'])))
        g.add((feat_uri, AQ.hasHealthRisk, Literal(info['risk'])))
    
    print("Expert knowledge rules added to graph.")

# --- 3. CONVERT PREDICTION TO RDF ---
def generate_rdf_for_prediction(g, prediction_id, features_dict, prediction_result):
    """
    Takes a single prediction row and converts it into triples.
    """
    pred_uri = URIRef(f"http://aqi-prediction.org/ontology#Pred_{prediction_id}")
    
    # Add Prediction Info
    g.add((pred_uri, RDF.type, AQ.Prediction))
    g.add((pred_uri, AQ.hasPredictedValue, Literal(prediction_result, datatype=XSD.float)))
    
    # Add Feature Influences (Looping through your specific columns)
    for name, value in features_dict.items():
        # Clean up name to be URI-safe (e.g., 'relative_humidity' -> 'Feature_relative_humidity')
        clean_name = name.replace(" ", "_")
        feat_uri = URIRef(f"http://aqi-prediction.org/ontology#Feature_{clean_name}")
        
        # Link prediction to the feature
        g.add((pred_uri, AQ.hasFeatureInput, feat_uri))
        g.add((feat_uri, AQ.hasObservedValue, Literal(value, datatype=XSD.float)))

# --- MAIN EXECUTION ---
if __name__ == "__main__":
    print("--- Starting RDF Knowledge Engine ---")
    
    # 1. Setup
    g = init_graph()
    add_expert_knowledge(g)

    # 2. Try to load real data (for testing the structure)
    if os.path.exists(CSV_PATH):
        try:
            print(f"Loading data from {CSV_PATH}...")
            df = pd.read_csv(CSV_PATH)
            
            # Get the last row of data to act as our "Current Scenario"
            latest_row = df.iloc[-1]
            pred_id = "Current_Observation"
            
            # Extract relevant columns based on your screenshot
            # We filter for numeric columns that likely went into the model
            feature_data = {
                "PM2.5": latest_row.get("PM2.5", 0),
                "NO2": latest_row.get("NO2", 0),
                "Ozone": latest_row.get("Ozone", 0),
                "temperature": latest_row.get("temperature", 0),
                "windspeed": latest_row.get("windspeed", 0)
            }
            
            # Use real AQI if available, otherwise mock it for this test
            predicted_aqi = latest_row.get("Final_AQI", 150) 
            
            generate_rdf_for_prediction(g, pred_id, feature_data, predicted_aqi)
            print(f"Generated RDF for observation: {pred_id}")
            
        except Exception as e:
            print(f"Error reading CSV: {e}")
    else:
        print(f"WARNING: Could not find CSV at {CSV_PATH}")

    # 3. Serialize Output
    output_file = "final_aqi_knowledge_graph.ttl"
    g.serialize(destination=output_file, format="turtle")
    print(f"SUCCESS: Knowledge Graph saved to '{output_file}'")
    print("---------------------------------------")