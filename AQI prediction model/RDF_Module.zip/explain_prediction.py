from rdflib import Graph

# 1. Load the file created by your knowledge engine
g = Graph()
try:
    g.parse("final_aqi_knowledge_graph.ttl", format="turtle")
    print("✅ Graph loaded successfully.")
except:
    print("❌ Could not find 'final_aqi_knowledge_graph.ttl'. Run knowledge_engine.py first!")
    exit()

# 2. The SPARQL Query (The "Brain" asking questions)
query = """
    PREFIX aq: <http://aqi-prediction.org/ontology#>
    
    SELECT ?feature ?value ?risk ?cause
    WHERE {
        ?prediction aq:hasFeatureInput ?featURI .
        ?featURI aq:hasObservedValue ?value ;
                 aq:hasHealthRisk ?risk ;
                 aq:hasLikelySource ?cause .
                 
        # Extract the simple name (e.g., "PM2.5" from the long URI)
        BIND(STRAFTER(STR(?featURI), "Feature_") AS ?feature)
    }
"""

# 3. Generate the Report
print("\n=== 📢 AIR QUALITY EXPLAINABILITY REPORT ===")
print(f"Based on the latest sensor data:\n")

results = list(g.query(query))

if not results:
    print("No critical factors found to report.")
else:
    for row in results:
        print(f"🔴 FACTOR: {row.feature}")
        print(f"   • Measured Value: {row.value}")
        print(f"   • Likely Cause:   {row.cause}")
        print(f"   • Health Impact:  {row.risk}")
        print("   -------------------------------------------------")  